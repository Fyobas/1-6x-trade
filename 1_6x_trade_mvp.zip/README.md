# 1.6X TRADE — Flutter MVP

Bu proje gerçek para kullanmayan bir demo/simülasyon prototipidir.

## Çalıştırma
1. Flutter SDK kurulu bir bilgisayarda:
   `flutter pub get`
2. Android cihaz/emülatör bağlayın.
3. `flutter run`
4. APK için: `flutter build apk --release`

## MVP özellikleri
- Demo bakiye
- BTC/ETH/SOL parite seçimi
- Long/Short
- 1x–50x kaldıraç seçimi
- Risk tutarı
- Otomatik 1:1.6 risk/getiri
- Demo işlem sonucu ve işlem geçmişi
- Kazanma oranı

Not: İşlem sonucu şu an sadece prototip amacıyla simüle edilir; borsa API'sine bağlı değildir.
